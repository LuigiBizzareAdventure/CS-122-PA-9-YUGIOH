#include "Header.h"

void EnterKey(void) {
	flushCin();
	cout << "Press The ENTER Key To Continue.";
	getchar();
	clrscr();
}